'use client';

import { useState } from 'react';
import { Mail, Phone, MapPin, Send, CheckCircle } from 'lucide-react';
import { messageApi } from '@/lib/api';
import toast from 'react-hot-toast';

export default function ContactPage() {
  const [form, setForm] = useState({ name: '', email: '', subject: '', message: '' });
  const [loading, setLoading] = useState(false);
  const [sent, setSent] = useState(false);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    try {
      await messageApi.send(form);
      setSent(true);
      toast.success('Message sent successfully!');
    } catch (err: any) {
      toast.error(err.response?.data?.message || 'Failed to send message. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Contact Us</h1>
          <p className="text-gray-500">Have a question? We'd love to hear from you.</p>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-16">
        <div className="grid lg:grid-cols-3 gap-12">
          <div className="space-y-8">
            <div>
              <h2 className="text-xl font-bold text-gray-900 mb-6">Get in touch</h2>
              <p className="text-gray-600 leading-relaxed">
                Our team is here to help. Reach out for support, partnerships, or general inquiries.
              </p>
            </div>
            {[
              { icon: Mail, label: 'Email', value: 'support@edustream.com', href: 'mailto:support@edustream.com' },
              { icon: Phone, label: 'Phone', value: '+1 (555) 000-0000', href: 'tel:+15550000000' },
              { icon: MapPin, label: 'Address', value: '123 Learning St, San Francisco, CA', href: '#' },
            ].map(({ icon: Icon, label, value, href }) => (
              <div key={label} className="flex items-start gap-4">
                <div className="w-10 h-10 bg-primary-50 rounded-xl flex items-center justify-center shrink-0">
                  <Icon className="w-5 h-5 text-primary-600" />
                </div>
                <div>
                  <p className="text-xs text-gray-400 uppercase tracking-wide font-medium mb-0.5">{label}</p>
                  <a href={href} className="text-gray-900 hover:text-primary-600 transition-colors">{value}</a>
                </div>
              </div>
            ))}
          </div>

          <div className="lg:col-span-2">
            {sent ? (
              <div className="bg-white rounded-2xl border border-gray-100 p-12 text-center shadow-sm">
                <CheckCircle className="w-16 h-16 text-accent-500 mx-auto mb-4" />
                <h3 className="text-2xl font-bold text-gray-900 mb-2">Message sent!</h3>
                <p className="text-gray-500 mb-6">We'll get back to you within 24–48 hours.</p>
                <button onClick={() => setSent(false)} className="btn-secondary">Send another message</button>
              </div>
            ) : (
              <div className="bg-white rounded-2xl border border-gray-100 p-8 shadow-sm">
                <form onSubmit={handleSubmit} className="space-y-5">
                  <div className="grid sm:grid-cols-2 gap-5">
                    <div>
                      <label className="label">Full name *</label>
                      <input
                        type="text"
                        value={form.name}
                        onChange={(e) => setForm(f => ({ ...f, name: e.target.value }))}
                        className="input"
                        placeholder="John Doe"
                        required
                        minLength={2}
                        maxLength={100}
                      />
                    </div>
                    <div>
                      <label className="label">Email address *</label>
                      <input
                        type="email"
                        value={form.email}
                        onChange={(e) => setForm(f => ({ ...f, email: e.target.value }))}
                        className="input"
                        placeholder="john@example.com"
                        required
                      />
                    </div>
                  </div>
                  <div>
                    <label className="label">Subject *</label>
                    <input
                      type="text"
                      value={form.subject}
                      onChange={(e) => setForm(f => ({ ...f, subject: e.target.value }))}
                      className="input"
                      placeholder="How can we help you?"
                      required
                      minLength={5}
                      maxLength={255}
                    />
                  </div>
                  <div>
                    <label className="label">Message *</label>
                    <textarea
                      value={form.message}
                      onChange={(e) => setForm(f => ({ ...f, message: e.target.value }))}
                      className="input h-36 resize-none"
                      placeholder="Tell us more about your inquiry..."
                      required
                      minLength={10}
                      maxLength={5000}
                    />
                    <p className="text-xs text-gray-400 mt-1">{form.message.length}/5000</p>
                  </div>
                  <button type="submit" disabled={loading} className="btn-primary flex items-center gap-2">
                    <Send className="w-4 h-4" />
                    {loading ? 'Sending...' : 'Send Message'}
                  </button>
                </form>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
