'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ChevronLeft, Search, Eye, Star } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { adminApi } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import toast from 'react-hot-toast';

export default function AdminCoursesPage() {
  const { user, isAuthenticated } = useAuthStore();
  const router = useRouter();
  const [search, setSearch] = useState('');
  const [page, setPage] = useState(1);
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!isAuthenticated || user?.role !== 'admin') router.push('/');
  }, [isAuthenticated, user]);

  const { data, isLoading } = useQuery({
    queryKey: ['admin-courses', search, page],
    queryFn: () => adminApi.getCourses({ search, page, limit: 15 }).then(r => r.data.data),
    enabled: user?.role === 'admin',
  });

  const updateCourse = useMutation({
    mutationFn: ({ id, ...data }: any) => adminApi.updateUser(id, data), // reuse updateUser or specific endpoint
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-courses'] });
      toast.success('Course updated');
    },
  });

  const difficultyColor: Record<string, string> = {
    beginner: 'bg-green-100 text-green-700',
    intermediate: 'bg-yellow-100 text-yellow-700',
    advanced: 'bg-red-100 text-red-700',
  };

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/admin" className="p-2 bg-white rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
            <ChevronLeft className="w-4 h-4" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">Manage Courses</h1>
        </div>

        <div className="bg-white rounded-xl border border-gray-100 p-5 mb-6 shadow-sm">
          <div className="relative max-w-md">
            <Search className="absolute left-3.5 top-1/2 -translate-y-1/2 w-4 h-4 text-gray-400" />
            <input
              type="text"
              value={search}
              onChange={(e) => { setSearch(e.target.value); setPage(1); }}
              placeholder="Search courses..."
              className="input pl-10"
            />
          </div>
        </div>

        <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50">
                  <th className="text-left px-5 py-3 font-semibold text-gray-600">Course</th>
                  <th className="text-left px-5 py-3 font-semibold text-gray-600">Instructor</th>
                  <th className="text-left px-5 py-3 font-semibold text-gray-600">Difficulty</th>
                  <th className="text-left px-5 py-3 font-semibold text-gray-600">Price</th>
                  <th className="text-left px-5 py-3 font-semibold text-gray-600">Rating</th>
                  <th className="text-left px-5 py-3 font-semibold text-gray-600">Students</th>
                  <th className="text-left px-5 py-3 font-semibold text-gray-600">Status</th>
                  <th className="text-left px-5 py-3 font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {isLoading
                  ? Array(5).fill(0).map((_, i) => (
                      <tr key={i}>
                        {Array(8).fill(0).map((_, j) => (
                          <td key={j} className="px-5 py-4"><div className="h-4 skeleton rounded w-20" /></td>
                        ))}
                      </tr>
                    ))
                  : data?.courses?.map((c: any) => (
                      <tr key={c.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-5 py-4">
                          <div className="flex items-center gap-3">
                            <div className="w-10 h-8 bg-primary-100 rounded overflow-hidden shrink-0">
                              {c.cover_image_url
                                ? <img src={c.cover_image_url} alt={c.title} className="w-full h-full object-cover" />
                                : <div className="w-full h-full bg-primary-200" />}
                            </div>
                            <p className="font-medium text-gray-900 line-clamp-1 max-w-xs">{c.title}</p>
                          </div>
                        </td>
                        <td className="px-5 py-4 text-gray-600">{c.instructor_name}</td>
                        <td className="px-5 py-4">
                          <span className={`badge ${difficultyColor[c.difficulty] || 'bg-gray-100 text-gray-600'}`}>
                            {c.difficulty}
                          </span>
                        </td>
                        <td className="px-5 py-4 text-gray-700">
                          {c.is_free ? <span className="text-accent-600 font-medium">Free</span> : `$${c.price}`}
                        </td>
                        <td className="px-5 py-4">
                          <span className="flex items-center gap-1 text-gray-700">
                            <Star className="w-3.5 h-3.5 text-amber-400 fill-amber-400" />
                            {(c.rating_average || 0).toFixed(1)}
                          </span>
                        </td>
                        <td className="px-5 py-4 text-gray-600">{(c.enrollment_count || 0).toLocaleString()}</td>
                        <td className="px-5 py-4">
                          <span className={`badge ${c.is_published ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                            {c.is_published ? 'Published' : 'Draft'}
                          </span>
                        </td>
                        <td className="px-5 py-4">
                          <Link
                            href={`/courses/${c.slug}`}
                            target="_blank"
                            className="p-1.5 text-gray-500 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors inline-flex"
                          >
                            <Eye className="w-4 h-4" />
                          </Link>
                        </td>
                      </tr>
                    ))}
              </tbody>
            </table>
          </div>
          {data?.total && (
            <div className="px-5 py-4 border-t border-gray-100 flex items-center justify-between text-sm text-gray-500">
              <span>{data.total} total courses</span>
              <div className="flex gap-2">
                <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="px-3 py-1 rounded border border-gray-200 disabled:opacity-40 hover:bg-gray-50">Prev</button>
                <button onClick={() => setPage(p => p + 1)} disabled={data.courses?.length < 15} className="px-3 py-1 rounded border border-gray-200 disabled:opacity-40 hover:bg-gray-50">Next</button>
              </div>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
