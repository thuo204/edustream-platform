'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ChevronLeft, Eye, Calendar } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { adminApi } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';

export default function AdminArticlesPage() {
  const { user, isAuthenticated } = useAuthStore();
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated || user?.role !== 'admin') router.push('/');
  }, [isAuthenticated, user]);

  const { data: articles = [], isLoading } = useQuery({
    queryKey: ['admin-articles'],
    queryFn: () => adminApi.getArticles().then(r => r.data.data),
    enabled: user?.role === 'admin',
  });

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/admin" className="p-2 bg-white rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
            <ChevronLeft className="w-4 h-4" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">Blog Articles</h1>
        </div>

        <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
          <div className="overflow-x-auto">
            <table className="w-full text-sm">
              <thead>
                <tr className="border-b border-gray-100 bg-gray-50">
                  <th className="text-left px-5 py-3 font-semibold text-gray-600">Article</th>
                  <th className="text-left px-5 py-3 font-semibold text-gray-600">Author</th>
                  <th className="text-left px-5 py-3 font-semibold text-gray-600">Category</th>
                  <th className="text-left px-5 py-3 font-semibold text-gray-600">Views</th>
                  <th className="text-left px-5 py-3 font-semibold text-gray-600">Published</th>
                  <th className="text-left px-5 py-3 font-semibold text-gray-600">Status</th>
                  <th className="text-left px-5 py-3 font-semibold text-gray-600">Actions</th>
                </tr>
              </thead>
              <tbody className="divide-y divide-gray-50">
                {isLoading
                  ? Array(5).fill(0).map((_, i) => (
                      <tr key={i}>
                        {Array(7).fill(0).map((_, j) => (
                          <td key={j} className="px-5 py-4"><div className="h-4 skeleton rounded w-24" /></td>
                        ))}
                      </tr>
                    ))
                  : articles.map((a: any) => (
                      <tr key={a.id} className="hover:bg-gray-50 transition-colors">
                        <td className="px-5 py-4">
                          <p className="font-medium text-gray-900 line-clamp-1 max-w-xs">{a.title}</p>
                        </td>
                        <td className="px-5 py-4 text-gray-600">{a.author_name}</td>
                        <td className="px-5 py-4">
                          {a.category_name && (
                            <span className="badge bg-blue-100 text-blue-700">{a.category_name}</span>
                          )}
                        </td>
                        <td className="px-5 py-4 text-gray-600">{(a.view_count || 0).toLocaleString()}</td>
                        <td className="px-5 py-4 text-gray-500 text-xs">
                          <span className="flex items-center gap-1">
                            <Calendar className="w-3 h-3" />
                            {a.published_at ? new Date(a.published_at).toLocaleDateString() : '—'}
                          </span>
                        </td>
                        <td className="px-5 py-4">
                          <span className={`badge ${a.status === 'published' ? 'bg-green-100 text-green-700' : 'bg-yellow-100 text-yellow-700'}`}>
                            {a.status || 'draft'}
                          </span>
                        </td>
                        <td className="px-5 py-4">
                          <Link
                            href={`/blog/${a.slug}`}
                            target="_blank"
                            className="p-1.5 text-gray-500 hover:text-primary-600 hover:bg-primary-50 rounded-lg transition-colors inline-flex"
                          >
                            <Eye className="w-4 h-4" />
                          </Link>
                        </td>
                      </tr>
                    ))}
              </tbody>
            </table>
          </div>
        </div>
      </div>
    </div>
  );
}
