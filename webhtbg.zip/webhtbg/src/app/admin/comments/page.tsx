'use client';

import { useState, useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ChevronLeft, Check, X, ExternalLink } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { adminApi } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import toast from 'react-hot-toast';

export default function AdminCommentsPage() {
  const { user, isAuthenticated } = useAuthStore();
  const router = useRouter();
  const [status, setStatus] = useState('pending');
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!isAuthenticated || user?.role !== 'admin') router.push('/');
  }, [isAuthenticated, user]);

  const { data: comments = [], isLoading } = useQuery({
    queryKey: ['admin-comments', status],
    queryFn: () => adminApi.getComments({ status }).then(r => r.data.data),
    enabled: user?.role === 'admin',
  });

  const updateComment = useMutation({
    mutationFn: ({ id, status }: any) => adminApi.updateComment(id, { status }),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['admin-comments'] });
      toast.success('Comment updated');
    },
  });

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <div className="max-w-5xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/admin" className="p-2 bg-white rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
            <ChevronLeft className="w-4 h-4" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">Comment Moderation</h1>
        </div>

        <div className="flex gap-2 mb-6">
          {['pending', 'approved', 'rejected', 'spam'].map(s => (
            <button
              key={s}
              onClick={() => setStatus(s)}
              className={`px-4 py-2 rounded-lg text-sm font-medium transition-colors capitalize ${status === s ? 'bg-primary-600 text-white' : 'bg-white border border-gray-200 text-gray-600 hover:bg-gray-50'}`}
            >
              {s}
            </button>
          ))}
        </div>

        <div className="space-y-4">
          {isLoading
            ? Array(4).fill(0).map((_, i) => <div key={i} className="h-28 skeleton rounded-xl" />)
            : comments.length === 0
            ? (
              <div className="text-center py-16 bg-white rounded-xl border border-gray-100">
                <p className="text-gray-400">No {status} comments</p>
              </div>
            )
            : comments.map((comment: any) => (
              <div key={comment.id} className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
                <div className="flex items-start justify-between gap-4">
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center gap-3 mb-2 flex-wrap">
                      <span className="font-semibold text-gray-900 text-sm">{comment.author_name || 'Anonymous'}</span>
                      {comment.author_email && <span className="text-xs text-gray-400">{comment.author_email}</span>}
                      <span className="text-xs text-gray-400">{new Date(comment.created_at).toLocaleDateString()}</span>
                    </div>
                    <p className="text-sm text-gray-700 leading-relaxed mb-3">{comment.content}</p>
                    <Link
                      href={`/blog/${comment.article_slug}`}
                      target="_blank"
                      className="text-xs text-primary-600 hover:underline flex items-center gap-1"
                    >
                      <ExternalLink className="w-3 h-3" />
                      {comment.article_title}
                    </Link>
                  </div>
                  {status === 'pending' && (
                    <div className="flex gap-2 shrink-0">
                      <button
                        onClick={() => updateComment.mutate({ id: comment.id, status: 'approved' })}
                        className="flex items-center gap-1.5 px-3 py-2 bg-green-50 hover:bg-green-100 text-green-700 rounded-lg text-sm font-medium transition-colors"
                      >
                        <Check className="w-4 h-4" /> Approve
                      </button>
                      <button
                        onClick={() => updateComment.mutate({ id: comment.id, status: 'rejected' })}
                        className="flex items-center gap-1.5 px-3 py-2 bg-red-50 hover:bg-red-100 text-red-700 rounded-lg text-sm font-medium transition-colors"
                      >
                        <X className="w-4 h-4" /> Reject
                      </button>
                      <button
                        onClick={() => updateComment.mutate({ id: comment.id, status: 'spam' })}
                        className="flex items-center gap-1.5 px-3 py-2 bg-gray-100 hover:bg-gray-200 text-gray-600 rounded-lg text-sm font-medium transition-colors"
                      >
                        Spam
                      </button>
                    </div>
                  )}
                </div>
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}
