'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { ChevronLeft, Mail, ChevronDown, ChevronUp } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { adminApi } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';

export default function AdminMessagesPage() {
  const { user, isAuthenticated } = useAuthStore();
  const router = useRouter();
  const [expanded, setExpanded] = useState<number | null>(null);

  useEffect(() => {
    if (!isAuthenticated || user?.role !== 'admin') router.push('/');
  }, [isAuthenticated, user]);

  const { data: messages = [], isLoading } = useQuery({
    queryKey: ['admin-messages'],
    queryFn: () => adminApi.getMessages().then(r => r.data.data),
    enabled: user?.role === 'admin',
  });

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/admin" className="p-2 bg-white rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
            <ChevronLeft className="w-4 h-4" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">Contact Messages</h1>
        </div>

        <div className="space-y-3">
          {isLoading
            ? Array(4).fill(0).map((_, i) => <div key={i} className="h-20 skeleton rounded-xl" />)
            : messages.length === 0
            ? (
              <div className="text-center py-16 bg-white rounded-xl border border-gray-100">
                <Mail className="w-10 h-10 text-gray-300 mx-auto mb-3" />
                <p className="text-gray-400">No messages yet</p>
              </div>
            )
            : messages.map((msg: any) => (
              <div key={msg.id} className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
                <button
                  onClick={() => setExpanded(expanded === msg.id ? null : msg.id)}
                  className="w-full px-5 py-4 flex items-center justify-between hover:bg-gray-50 transition-colors text-left"
                >
                  <div className="flex items-center gap-4 min-w-0">
                    <div className="w-9 h-9 bg-primary-100 rounded-full flex items-center justify-center shrink-0">
                      <Mail className="w-4 h-4 text-primary-600" />
                    </div>
                    <div className="min-w-0">
                      <p className="font-semibold text-gray-900 text-sm">{msg.name}</p>
                      <p className="text-xs text-gray-400">{msg.email} · {msg.subject}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3 shrink-0 ml-4">
                    <span className="text-xs text-gray-400">{new Date(msg.created_at).toLocaleDateString()}</span>
                    {expanded === msg.id ? <ChevronUp className="w-4 h-4 text-gray-400" /> : <ChevronDown className="w-4 h-4 text-gray-400" />}
                  </div>
                </button>
                {expanded === msg.id && (
                  <div className="px-5 pb-5 border-t border-gray-100">
                    <p className="text-sm text-gray-700 leading-relaxed pt-4 whitespace-pre-wrap">{msg.message}</p>
                    <a
                      href={`mailto:${msg.email}?subject=Re: ${msg.subject}`}
                      className="mt-4 inline-flex items-center gap-2 px-4 py-2 bg-primary-600 text-white rounded-lg text-sm font-medium hover:bg-primary-700 transition-colors"
                    >
                      <Mail className="w-4 h-4" /> Reply via Email
                    </a>
                  </div>
                )}
              </div>
            ))}
        </div>
      </div>
    </div>
  );
}
