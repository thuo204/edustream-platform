'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { Bookmark, BookOpen, ChevronLeft, Trash2 } from 'lucide-react';
import { useQuery, useMutation, useQueryClient } from '@tanstack/react-query';
import { bookmarkApi } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';
import toast from 'react-hot-toast';

export default function BookmarksPage() {
  const { isAuthenticated } = useAuthStore();
  const router = useRouter();
  const queryClient = useQueryClient();

  useEffect(() => {
    if (!isAuthenticated) router.push('/auth/login?redirect=/dashboard/bookmarks');
  }, [isAuthenticated]);

  const { data: bookmarks = [], isLoading } = useQuery({
    queryKey: ['bookmarks'],
    queryFn: () => bookmarkApi.getAll().then(r => r.data.data),
    enabled: isAuthenticated,
  });

  const removeBookmark = useMutation({
    mutationFn: (id: string) => bookmarkApi.remove(id),
    onSuccess: () => {
      queryClient.invalidateQueries({ queryKey: ['bookmarks'] });
      toast.success('Bookmark removed');
    },
  });

  if (!isAuthenticated) return null;

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/dashboard" className="p-2 bg-white rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
            <ChevronLeft className="w-4 h-4" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">My Bookmarks</h1>
        </div>

        {isLoading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(6).fill(0).map((_, i) => (
              <div key={i} className="card overflow-hidden">
                <div className="aspect-video skeleton" />
                <div className="p-5 space-y-3">
                  <div className="h-4 skeleton rounded w-3/4" />
                  <div className="h-3 skeleton rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : bookmarks.length === 0 ? (
          <div className="text-center py-20">
            <Bookmark className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No bookmarks yet</h3>
            <p className="text-gray-500 mb-6">Save courses and articles to access them later</p>
            <Link href="/courses" className="btn-primary">Browse Courses</Link>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {bookmarks.map((bookmark: any) => (
              <div key={bookmark.id} className="card overflow-hidden relative">
                <button
                  onClick={() => removeBookmark.mutate(bookmark.id)}
                  className="absolute top-3 right-3 z-10 p-1.5 bg-white/90 rounded-full text-red-500 hover:bg-red-50 transition-colors shadow-sm"
                >
                  <Trash2 className="w-3.5 h-3.5" />
                </button>
                <div className="aspect-video overflow-hidden bg-gray-100">
                  {bookmark.cover_image_url ? (
                    <img src={bookmark.cover_image_url} alt={bookmark.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-primary-100 to-primary-200 flex items-center justify-center">
                      <BookOpen className="w-12 h-12 text-primary-400" />
                    </div>
                  )}
                </div>
                <div className="p-5">
                  <p className="text-xs font-medium text-primary-600 uppercase tracking-wide mb-1">{bookmark.item_type}</p>
                  <h3 className="font-semibold text-gray-900 mb-3 line-clamp-2">{bookmark.title}</h3>
                  <Link
                    href={bookmark.item_type === 'course' ? `/courses/${bookmark.slug}` : `/blog/${bookmark.slug}`}
                    className="text-sm text-primary-600 hover:underline"
                  >
                    {bookmark.item_type === 'course' ? 'View Course' : 'Read Article'} →
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
