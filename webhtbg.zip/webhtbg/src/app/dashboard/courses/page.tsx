'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { BookOpen, Play, Award, ChevronLeft } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { enrollmentApi } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';

export default function MyCoursesPage() {
  const { isAuthenticated } = useAuthStore();
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated) router.push('/auth/login?redirect=/dashboard/courses');
  }, [isAuthenticated]);

  const { data: enrollments = [], isLoading } = useQuery({
    queryKey: ['my-enrollments'],
    queryFn: () => enrollmentApi.getMyEnrollments().then(r => r.data.data),
    enabled: isAuthenticated,
  });

  if (!isAuthenticated) return null;

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        <div className="flex items-center gap-4 mb-8">
          <Link href="/dashboard" className="p-2 bg-white rounded-lg border border-gray-200 hover:bg-gray-50 transition-colors">
            <ChevronLeft className="w-4 h-4" />
          </Link>
          <h1 className="text-2xl font-bold text-gray-900">My Courses</h1>
        </div>

        {isLoading ? (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {Array(6).fill(0).map((_, i) => (
              <div key={i} className="card overflow-hidden">
                <div className="aspect-video skeleton" />
                <div className="p-5 space-y-3">
                  <div className="h-4 skeleton rounded w-3/4" />
                  <div className="h-3 skeleton rounded" />
                </div>
              </div>
            ))}
          </div>
        ) : enrollments.length === 0 ? (
          <div className="text-center py-20">
            <BookOpen className="w-16 h-16 text-gray-300 mx-auto mb-4" />
            <h3 className="text-lg font-semibold text-gray-900 mb-2">No courses yet</h3>
            <p className="text-gray-500 mb-6">Start learning by enrolling in your first course</p>
            <Link href="/courses" className="btn-primary">Browse Courses</Link>
          </div>
        ) : (
          <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-6">
            {enrollments.map((enrollment: any) => (
              <div key={enrollment.id} className="card overflow-hidden">
                <div className="aspect-video overflow-hidden bg-gray-100 relative">
                  {enrollment.cover_image_url ? (
                    <img src={enrollment.cover_image_url} alt={enrollment.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full bg-gradient-to-br from-primary-100 to-primary-200 flex items-center justify-center">
                      <BookOpen className="w-12 h-12 text-primary-400" />
                    </div>
                  )}
                  {enrollment.status === 'completed' && (
                    <div className="absolute top-3 right-3 bg-accent-500 text-white text-xs font-bold px-2 py-1 rounded-full flex items-center gap-1">
                      <Award className="w-3 h-3" /> Completed
                    </div>
                  )}
                </div>
                <div className="p-5">
                  <h3 className="font-semibold text-gray-900 mb-1 line-clamp-2">{enrollment.title}</h3>
                  <p className="text-xs text-gray-500 mb-4">{enrollment.instructor_name}</p>
                  <div className="mb-4">
                    <div className="flex items-center justify-between text-xs text-gray-500 mb-1">
                      <span>Progress</span>
                      <span>{enrollment.progress_percentage || 0}%</span>
                    </div>
                    <div className="bg-gray-200 rounded-full h-2">
                      <div
                        className="bg-primary-600 h-2 rounded-full transition-all"
                        style={{ width: `${enrollment.progress_percentage || 0}%` }}
                      />
                    </div>
                  </div>
                  <Link
                    href={`/courses/${enrollment.slug}/learn`}
                    className="w-full flex items-center justify-center gap-2 btn-primary text-sm"
                  >
                    <Play className="w-4 h-4 fill-white" />
                    {enrollment.progress_percentage > 0 ? 'Continue' : 'Start Learning'}
                  </Link>
                </div>
              </div>
            ))}
          </div>
        )}
      </div>
    </div>
  );
}
