import type { Metadata } from 'next';

export const metadata: Metadata = {
  title: 'Terms of Service',
  description: 'EduStream Terms of Service',
};

export default function TermsPage() {
  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <div className="bg-white border-b border-gray-100">
        <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
          <h1 className="text-3xl font-bold text-gray-900 mb-2">Terms of Service</h1>
          <p className="text-gray-500">Last updated: January 1, 2026</p>
        </div>
      </div>
      <div className="max-w-4xl mx-auto px-4 sm:px-6 lg:px-8 py-12">
        <div className="bg-white rounded-2xl border border-gray-100 p-10 shadow-sm prose max-w-none">
          <h2>1. Acceptance of Terms</h2>
          <p>By accessing and using EduStream, you accept and agree to be bound by these Terms of Service. If you do not agree to these terms, please do not use our platform.</p>

          <h2>2. Use of the Platform</h2>
          <p>You agree to use EduStream only for lawful purposes and in accordance with these Terms. You agree not to use the platform to upload or transmit any harmful, offensive, or illegal content.</p>

          <h2>3. Account Registration</h2>
          <p>To access certain features, you may need to create an account. You are responsible for maintaining the confidentiality of your account credentials and for all activities that occur under your account.</p>

          <h2>4. Course Content</h2>
          <p>All course content on EduStream is protected by copyright. You may not reproduce, distribute, or create derivative works from any content without express written permission from EduStream or the respective content creators.</p>

          <h2>5. Payment and Refunds</h2>
          <p>Course purchases are subject to our pricing displayed at the time of purchase. We offer a 30-day money-back guarantee for paid courses if you are not satisfied with the content.</p>

          <h2>6. Termination</h2>
          <p>We reserve the right to terminate or suspend your account at any time if you violate these Terms of Service. You may also terminate your account at any time by contacting our support team.</p>

          <h2>7. Contact</h2>
          <p>For questions about these Terms, please contact us at legal@edustream.com.</p>
        </div>
      </div>
    </div>
  );
}
