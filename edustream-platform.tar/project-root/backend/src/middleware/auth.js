const jwt = require('jsonwebtoken');
const { query } = require('../config/database');
const { cacheGet, cacheSet } = require('../config/redis');

async function authenticate(req, res, next) {
  try {
    const authHeader = req.headers.authorization;
    
    if (!authHeader || !authHeader.startsWith('Bearer ')) {
      return res.status(401).json({ success: false, message: 'Authentication required' });
    }
    
    const token = authHeader.split(' ')[1];
    
    if (!token) {
      return res.status(401).json({ success: false, message: 'Invalid token format' });
    }
    
    let decoded;
    try {
      decoded = jwt.verify(token, process.env.JWT_SECRET);
    } catch (err) {
      if (err.name === 'TokenExpiredError') {
        return res.status(401).json({ success: false, message: 'Token expired', code: 'TOKEN_EXPIRED' });
      }
      return res.status(401).json({ success: false, message: 'Invalid token' });
    }
    
    // Check cache first
    const cacheKey = `user:${decoded.id}`;
    let user = await cacheGet(cacheKey);
    
    if (!user) {
      const result = await query(
        'SELECT id, email, username, full_name, avatar_url, role, is_active, is_verified FROM users WHERE id = $1',
        [decoded.id]
      );
      
      if (!result.rows.length) {
        return res.status(401).json({ success: false, message: 'User not found' });
      }
      
      user = result.rows[0];
      await cacheSet(cacheKey, user, 300); // 5 min cache
    }
    
    if (!user.is_active) {
      return res.status(403).json({ success: false, message: 'Account suspended' });
    }
    
    req.user = user;
    next();
  } catch (error) {
    return res.status(500).json({ success: false, message: 'Authentication error' });
  }
}

function authorize(...roles) {
  return (req, res, next) => {
    if (!req.user) {
      return res.status(401).json({ success: false, message: 'Authentication required' });
    }
    
    if (!roles.includes(req.user.role)) {
      return res.status(403).json({ 
        success: false, 
        message: 'Insufficient permissions' 
      });
    }
    
    next();
  };
}

function optionalAuth(req, res, next) {
  const authHeader = req.headers.authorization;
  
  if (!authHeader || !authHeader.startsWith('Bearer ')) {
    return next();
  }
  
  authenticate(req, res, next);
}

module.exports = { authenticate, authorize, optionalAuth };
