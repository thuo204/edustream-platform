const express = require('express');
const router = express.Router();
const { body, param, query } = require('express-validator');
const { authenticate, authorize, optionalAuth } = require('../middleware/auth');
const { authRateLimiter } = require('../middleware/rateLimiter');
const { validateHeaders, sanitizeInput } = require('../middleware/security');
const authController = require('../controllers/authController');
const { asyncHandler } = require('../middleware/errorHandler');

const validationMiddleware = async (req, res, next) => {
  const { validationResult } = require('express-validator');
  const errors = validationResult(req);
  if (!errors.isEmpty()) {
    return res.status(422).json({
      success: false,
      message: 'Validation failed',
      errors: errors.array().map(e => ({ field: e.path, message: e.msg }))
    });
  }
  next();
};

// Auth routes
router.post('/register',
  authRateLimiter,
  sanitizeInput,
  [
    body('email').isEmail().normalizeEmail(),
    body('username').isLength({ min: 3, max: 30 }).matches(/^[a-zA-Z0-9_]+$/),
    body('password').isLength({ min: 8 }).matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/),
    body('full_name').isLength({ min: 2, max: 100 }),
  ],
  validationMiddleware,
  authController.register
);

router.post('/login',
  authRateLimiter,
  sanitizeInput,
  [
    body('email').isEmail().normalizeEmail(),
    body('password').notEmpty(),
  ],
  validationMiddleware,
  authController.login
);

router.post('/refresh', authController.refreshToken);
router.post('/logout', authenticate, authController.logout);
router.get('/me', authenticate, authController.getMe);
router.put('/change-password',
  authenticate,
  [
    body('current_password').notEmpty(),
    body('new_password').isLength({ min: 8 }).matches(/^(?=.*[a-z])(?=.*[A-Z])(?=.*\d)/),
  ],
  validationMiddleware,
  authController.changePassword
);

module.exports = router;
