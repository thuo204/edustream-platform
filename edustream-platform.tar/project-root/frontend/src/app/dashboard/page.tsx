'use client';

import { useEffect } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import { BookOpen, Clock, Award, Bookmark, Bell, TrendingUp, Play, ChevronRight } from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { enrollmentApi, notificationApi } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';

export default function DashboardPage() {
  const { isAuthenticated, user } = useAuthStore();
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated) router.push('/auth/login?redirect=/dashboard');
  }, [isAuthenticated]);

  const { data: enrollments = [] } = useQuery({
    queryKey: ['my-enrollments'],
    queryFn: () => enrollmentApi.getMyEnrollments().then(r => r.data.data),
    enabled: isAuthenticated,
  });

  const { data: notificationsData } = useQuery({
    queryKey: ['notifications'],
    queryFn: () => notificationApi.getAll().then(r => r.data.data),
    enabled: isAuthenticated,
  });

  const stats = [
    { icon: BookOpen, label: 'Enrolled Courses', value: enrollments.length, color: 'text-primary-600 bg-primary-50' },
    { icon: TrendingUp, label: 'In Progress', value: enrollments.filter((e: any) => e.progress_percentage > 0 && e.progress_percentage < 100).length, color: 'text-accent-600 bg-accent-50' },
    { icon: Award, label: 'Completed', value: enrollments.filter((e: any) => e.status === 'completed').length, color: 'text-amber-600 bg-amber-50' },
    { icon: Bell, label: 'Notifications', value: notificationsData?.unread_count || 0, color: 'text-purple-600 bg-purple-50' },
  ];

  if (!isAuthenticated) return null;

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Header */}
        <div className="mb-10">
          <h1 className="text-3xl font-bold text-gray-900">
            Welcome back, {user?.full_name?.split(' ')[0]}! 👋
          </h1>
          <p className="text-gray-500 mt-1">Continue your learning journey</p>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-4 gap-5 mb-10">
          {stats.map(({ icon: Icon, label, value, color }) => (
            <div key={label} className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${color}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="text-2xl font-bold text-gray-900">{value}</div>
              <div className="text-sm text-gray-500 mt-0.5">{label}</div>
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* My Courses */}
          <div className="lg:col-span-2">
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-xl font-bold text-gray-900">My Courses</h2>
              <Link href="/dashboard/courses" className="text-sm text-primary-600 hover:underline flex items-center gap-1">
                View all <ChevronRight className="w-4 h-4" />
              </Link>
            </div>

            {enrollments.length === 0 ? (
              <div className="bg-white rounded-xl border border-gray-100 p-10 text-center">
                <BookOpen className="w-12 h-12 text-gray-300 mx-auto mb-4" />
                <h3 className="font-semibold text-gray-900 mb-2">No courses yet</h3>
                <p className="text-gray-500 text-sm mb-4">Start learning by enrolling in a course</p>
                <Link href="/courses" className="btn-primary text-sm">Browse Courses</Link>
              </div>
            ) : (
              <div className="space-y-4">
                {enrollments.slice(0, 5).map((enrollment: any) => (
                  <div key={enrollment.id} className="bg-white rounded-xl border border-gray-100 p-5 flex items-center gap-5 shadow-sm hover:shadow-md transition-shadow">
                    <div className="w-16 h-12 bg-primary-100 rounded-lg flex items-center justify-center shrink-0 overflow-hidden">
                      {enrollment.cover_image_url ? (
                        <img src={enrollment.cover_image_url} alt={enrollment.title} className="w-full h-full object-cover" />
                      ) : (
                        <BookOpen className="w-6 h-6 text-primary-400" />
                      )}
                    </div>
                    <div className="flex-1 min-w-0">
                      <h3 className="font-semibold text-gray-900 truncate text-sm">{enrollment.title}</h3>
                      <p className="text-xs text-gray-500 mt-0.5">{enrollment.instructor_name}</p>
                      <div className="mt-2 flex items-center gap-3">
                        <div className="flex-1 bg-gray-200 rounded-full h-1.5">
                          <div
                            className="bg-primary-600 h-1.5 rounded-full transition-all"
                            style={{ width: `${enrollment.progress_percentage || 0}%` }}
                          />
                        </div>
                        <span className="text-xs text-gray-500 shrink-0">{enrollment.progress_percentage || 0}%</span>
                      </div>
                    </div>
                    <Link
                      href={`/courses/${enrollment.slug}/learn`}
                      className="shrink-0 flex items-center gap-1.5 bg-primary-600 hover:bg-primary-700 text-white text-xs font-medium px-3 py-2 rounded-lg transition-colors"
                    >
                      <Play className="w-3.5 h-3.5 fill-white" />
                      Continue
                    </Link>
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* Sidebar */}
          <div className="space-y-6">
            {/* Recent notifications */}
            <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
              <div className="flex items-center justify-between mb-4">
                <h3 className="font-bold text-gray-900">Notifications</h3>
                <Link href="/dashboard/notifications" className="text-xs text-primary-600 hover:underline">View all</Link>
              </div>
              {notificationsData?.notifications?.length > 0 ? (
                <div className="space-y-3">
                  {notificationsData.notifications.slice(0, 4).map((n: any) => (
                    <div key={n.id} className={`flex gap-3 p-2 rounded-lg ${!n.is_read ? 'bg-primary-50' : ''}`}>
                      <div className="w-2 h-2 bg-primary-500 rounded-full mt-2 shrink-0" />
                      <div>
                        <p className="text-sm font-medium text-gray-900">{n.title}</p>
                        {n.message && <p className="text-xs text-gray-500 mt-0.5">{n.message}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-gray-400 text-center py-4">No notifications</p>
              )}
            </div>

            {/* Quick links */}
            <div className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
              <h3 className="font-bold text-gray-900 mb-4">Quick Links</h3>
              <div className="space-y-2">
                {[
                  { href: '/courses', icon: BookOpen, label: 'Browse Courses' },
                  { href: '/dashboard/bookmarks', icon: Bookmark, label: 'My Bookmarks' },
                  { href: '/dashboard/notifications', icon: Bell, label: 'Notifications' },
                ].map(({ href, icon: Icon, label }) => (
                  <Link key={href} href={href} className="flex items-center gap-3 py-2 text-sm text-gray-600 hover:text-primary-600 transition-colors">
                    <Icon className="w-4 h-4" />
                    {label}
                  </Link>
                ))}
              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
