import type { Metadata } from 'next';
import { notFound } from 'next/navigation';
import { CourseDetailClient } from '@/components/course/CourseDetailClient';

async function getCourse(slug: string) {
  try {
    const res = await fetch(`${process.env.NEXT_PUBLIC_API_URL}/api/v1/courses/${slug}`, {
      next: { revalidate: 600 }
    });
    if (!res.ok) return null;
    const data = await res.json();
    return data.data;
  } catch {
    return null;
  }
}

export async function generateMetadata({ params }: { params: { slug: string } }): Promise<Metadata> {
  const course = await getCourse(params.slug);
  if (!course) return {};
  return {
    title: course.seo_title || course.title,
    description: course.seo_description || course.short_description,
    openGraph: {
      title: course.title,
      description: course.short_description,
      images: [{ url: course.cover_image_url || '/og-default.png' }],
      type: 'website',
    },
  };
}

export default async function CourseDetailPage({ params }: { params: { slug: string } }) {
  const course = await getCourse(params.slug);
  if (!course) notFound();

  // Schema markup
  const schema = {
    '@context': 'https://schema.org',
    '@type': 'Course',
    name: course.title,
    description: course.short_description,
    provider: { '@type': 'Organization', name: 'EduStream' },
    instructor: { '@type': 'Person', name: course.instructor_name },
    offers: {
      '@type': 'Offer',
      price: course.price || 0,
      priceCurrency: 'USD',
      availability: 'https://schema.org/InStock',
    },
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(schema) }} />
      <CourseDetailClient course={course} />
    </>
  );
}
