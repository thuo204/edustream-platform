import type { Metadata } from 'next';
import { HeroSection } from '@/components/layout/HeroSection';
import { FeaturedCourses } from '@/components/course/FeaturedCourses';
import { FeaturedArticles } from '@/components/blog/FeaturedArticles';
import { StatsSection } from '@/components/layout/StatsSection';
import { CategoryGrid } from '@/components/layout/CategoryGrid';
import { AdBanner } from '@/components/ads/AdBanner';

export const metadata: Metadata = {
  title: 'EduStream - Learn, Grow, Succeed',
  description: 'Access 500+ expert-led courses, insightful articles, and join 50,000+ learners worldwide.',
};

export default async function HomePage() {
  return (
    <div>
      <HeroSection />
      <StatsSection />
      
      {/* Homepage Banner Ad */}
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-4">
        <AdBanner placement="homepage_banner" />
      </div>
      
      <CategoryGrid />
      <FeaturedCourses />
      <FeaturedArticles />
    </div>
  );
}
