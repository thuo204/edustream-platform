'use client';

import { useEffect, useState } from 'react';
import { useRouter } from 'next/navigation';
import Link from 'next/link';
import {
  Users, BookOpen, FileText, MessageSquare, Mail, DollarSign,
  TrendingUp, BarChart2, Settings, Shield, ChevronRight, Eye
} from 'lucide-react';
import { useQuery } from '@tanstack/react-query';
import { adminApi } from '@/lib/api';
import { useAuthStore } from '@/store/authStore';

export default function AdminDashboard() {
  const { isAuthenticated, user } = useAuthStore();
  const router = useRouter();

  useEffect(() => {
    if (!isAuthenticated) router.push('/auth/login?redirect=/admin');
    else if (user?.role !== 'admin') router.push('/dashboard');
  }, [isAuthenticated, user]);

  const { data: stats } = useQuery({
    queryKey: ['admin-stats'],
    queryFn: () => adminApi.getStats().then(r => r.data.data),
    enabled: isAuthenticated && user?.role === 'admin',
    refetchInterval: 60000,
  });

  const { data: recentUsers } = useQuery({
    queryKey: ['admin-users-recent'],
    queryFn: () => adminApi.getUsers({ limit: 5 }).then(r => r.data.data),
    enabled: isAuthenticated && user?.role === 'admin',
  });

  if (!isAuthenticated || user?.role !== 'admin') return null;

  const statCards = [
    { icon: Users, label: 'Total Users', value: stats?.total_users, sub: `+${stats?.new_users_30d} this month`, color: 'bg-blue-50 text-blue-600' },
    { icon: BookOpen, label: 'Total Courses', value: stats?.total_courses, color: 'bg-purple-50 text-purple-600' },
    { icon: FileText, label: 'Published Articles', value: stats?.total_articles, color: 'bg-green-50 text-green-600' },
    { icon: TrendingUp, label: 'Enrollments', value: stats?.total_enrollments, color: 'bg-amber-50 text-amber-600' },
    { icon: DollarSign, label: 'Total Revenue', value: `$${(stats?.total_revenue || 0).toLocaleString()}`, color: 'bg-emerald-50 text-emerald-600' },
    { icon: Mail, label: 'Unread Messages', value: stats?.unread_messages, color: 'bg-red-50 text-red-600' },
  ];

  const adminNav = [
    { href: '/admin/users', icon: Users, label: 'Manage Users', desc: 'View and manage user accounts' },
    { href: '/admin/courses', icon: BookOpen, label: 'Manage Courses', desc: 'Review and publish courses' },
    { href: '/admin/articles', icon: FileText, label: 'Blog Articles', desc: 'Create and manage blog posts' },
    { href: '/admin/comments', icon: MessageSquare, label: 'Moderate Comments', desc: 'Approve or reject comments' },
    { href: '/admin/messages', icon: Mail, label: 'Contact Messages', desc: 'View contact form submissions' },
    { href: '/admin/analytics', icon: BarChart2, label: 'Analytics', desc: 'View platform analytics' },
  ];

  return (
    <div className="min-h-screen bg-[#F8FAFC]">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-10">
        {/* Header */}
        <div className="flex items-center justify-between mb-10">
          <div>
            <div className="flex items-center gap-2 mb-1">
              <Shield className="w-5 h-5 text-primary-600" />
              <span className="text-sm font-medium text-primary-600 uppercase tracking-wide">Admin Panel</span>
            </div>
            <h1 className="text-3xl font-bold text-gray-900">Dashboard Overview</h1>
          </div>
          <div className="text-sm text-gray-500">
            {new Date().toLocaleDateString('en-US', { weekday: 'long', year: 'numeric', month: 'long', day: 'numeric' })}
          </div>
        </div>

        {/* Stats */}
        <div className="grid grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-5 mb-10">
          {statCards.map(({ icon: Icon, label, value, sub, color }) => (
            <div key={label} className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm">
              <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-3 ${color}`}>
                <Icon className="w-5 h-5" />
              </div>
              <div className="text-2xl font-bold text-gray-900">{value ?? '—'}</div>
              <div className="text-xs text-gray-500 mt-0.5">{label}</div>
              {sub && <div className="text-xs text-accent-600 mt-1">{sub}</div>}
            </div>
          ))}
        </div>

        <div className="grid lg:grid-cols-3 gap-8">
          {/* Admin Navigation */}
          <div className="lg:col-span-2">
            <h2 className="text-xl font-bold text-gray-900 mb-5">Management</h2>
            <div className="grid sm:grid-cols-2 gap-4">
              {adminNav.map(({ href, icon: Icon, label, desc }) => (
                <Link
                  key={href}
                  href={href}
                  className="bg-white rounded-xl border border-gray-100 p-5 shadow-sm hover:shadow-md hover:border-primary-200 transition-all group"
                >
                  <div className="flex items-start justify-between mb-3">
                    <div className="w-10 h-10 bg-primary-50 rounded-lg flex items-center justify-center">
                      <Icon className="w-5 h-5 text-primary-600" />
                    </div>
                    <ChevronRight className="w-4 h-4 text-gray-400 group-hover:text-primary-600 group-hover:translate-x-0.5 transition-all" />
                  </div>
                  <h3 className="font-semibold text-gray-900 mb-1">{label}</h3>
                  <p className="text-xs text-gray-500">{desc}</p>
                </Link>
              ))}
            </div>
          </div>

          {/* Recent Users */}
          <div>
            <div className="flex items-center justify-between mb-5">
              <h2 className="text-xl font-bold text-gray-900">Recent Users</h2>
              <Link href="/admin/users" className="text-xs text-primary-600 hover:underline">View all</Link>
            </div>
            <div className="bg-white rounded-xl border border-gray-100 shadow-sm overflow-hidden">
              {recentUsers?.users?.map((u: any, i: number) => (
                <div key={u.id} className={`flex items-center gap-3 p-4 ${i < (recentUsers.users.length - 1) ? 'border-b border-gray-50' : ''}`}>
                  <div className="w-9 h-9 bg-primary-100 rounded-full flex items-center justify-center shrink-0">
                    <span className="text-primary-700 text-sm font-semibold">{u.full_name?.charAt(0)}</span>
                  </div>
                  <div className="flex-1 min-w-0">
                    <p className="text-sm font-medium text-gray-900 truncate">{u.full_name}</p>
                    <p className="text-xs text-gray-400 truncate">{u.email}</p>
                  </div>
                  <span className={`text-xs px-2 py-0.5 rounded-full font-medium ${
                    u.role === 'admin' ? 'bg-red-100 text-red-700' :
                    u.role === 'instructor' ? 'bg-blue-100 text-blue-700' :
                    'bg-gray-100 text-gray-600'
                  }`}>
                    {u.role}
                  </span>
                </div>
              ))}
              {!recentUsers?.users?.length && (
                <div className="p-8 text-center text-gray-400 text-sm">No users found</div>
              )}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
